// A Bison parser, made by GNU Bison 3.0.4.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.


// First part of user declarations.

#line 37 "gen/parser.tab.cc" // lalr1.cc:404

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

#include "parser.tab.hh"

// User implementation prologue.

#line 51 "gen/parser.tab.cc" // lalr1.cc:412
// Unqualified %code blocks.
#line 8 "src/parser.yy" // lalr1.cc:413
 
	#include <string>
	#include <stdio.h>
	#define YY_DECL yy::parser::symbol_type yylex()
	unsigned int mathjax_total = 0;
	YY_DECL;
	void process_module(std::string module);
	std::string div_openaghmathjax(std::map<std::string, std::string> attrs, std::string body);
	std::string div();
	std::string div(std::string cl);
	std::string div(std::string openaghname, std::map<std::string, std::string> attrs, std::string body);
	std::string div(std::string openaghname, std::map<std::string, std::string> attrs);

#line 67 "gen/parser.tab.cc" // lalr1.cc:413


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif



// Suppress unused-variable warnings by "using" E.
#define YYUSE(E) ((void) (E))

// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << std::endl;                  \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yystack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YYUSE(Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void>(0)
# define YY_STACK_PRINT()                static_cast<void>(0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)


namespace yy {
#line 134 "gen/parser.tab.cc" // lalr1.cc:479

  /// Build a parser object.
  parser::parser ()
#if YYDEBUG
     :yydebug_ (false),
      yycdebug_ (&std::cerr)
#endif
  {}

  parser::~parser ()
  {}


  /*---------------.
  | Symbol types.  |
  `---------------*/



  // by_state.
  inline
  parser::by_state::by_state ()
    : state (empty_state)
  {}

  inline
  parser::by_state::by_state (const by_state& other)
    : state (other.state)
  {}

  inline
  void
  parser::by_state::clear ()
  {
    state = empty_state;
  }

  inline
  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  inline
  parser::by_state::by_state (state_type s)
    : state (s)
  {}

  inline
  parser::symbol_number_type
  parser::by_state::type_get () const
  {
    if (state == empty_state)
      return empty_symbol;
    else
      return yystos_[state];
  }

  inline
  parser::stack_symbol_type::stack_symbol_type ()
  {}


  inline
  parser::stack_symbol_type::stack_symbol_type (state_type s, symbol_type& that)
    : super_type (s)
  {
      switch (that.type_get ())
    {
      case 102: // xopenaghmathjaxattrs
      case 103: // xopenaghtheoremattrs
      case 104: // xopenaghexerciseattrs
      case 105: // xopenaghimgformulaattrs
      case 106: // x_name_anchor
        value.move< std::map<std::string, std::string> > (that.value);
        break;

      case 107: // xname
      case 108: // xanchor
      case 109: // xisnumeration
      case 110: // xtype
      case 111: // xassumptions
      case 112: // xthesis
      case 113: // xproof
      case 114: // xcontent
      case 115: // xsolution
      case 116: // xnote
      case 117: // xheadline
      case 118: // xfileid
      case 119: // xformulatype
        value.move< std::pair<std::string, std::string> > (that.value);
        break;

      case 3: // OPENAGHLEMMASTART
      case 4: // OPENAGHDEFINITIONSTART
      case 5: // OPENAGHEXAMPLESTART
      case 6: // OPENAGHLAWSTART
      case 7: // OPENAGHRULESTART
      case 8: // OPENAGHCONCLUSIONSTART
      case 9: // OPENAGHDERIVATIONSTART
      case 10: // OPENAGHSUMMARYSTART
      case 11: // OPENAGHINFORMATIONSTART
      case 12: // OPENAGHANNOTATIONSTART
      case 13: // OPENAGHPROPERTYSTART
      case 14: // OPENAGHMATHJAXSTART
      case 15: // OPENAGHLEMMAEND
      case 16: // OPENAGHDEFINITIONEND
      case 17: // OPENAGHEXAMPLEEND
      case 18: // OPENAGHLAWEND
      case 19: // OPENAGHRULEEND
      case 20: // OPENAGHCONCLUSIONEND
      case 21: // OPENAGHDERIVATIONEND
      case 22: // OPENAGHSUMMARYEND
      case 23: // OPENAGHINFORMATIONEND
      case 24: // OPENAGHANNOTATIONEND
      case 25: // OPENAGHPROPERTYEND
      case 26: // OPENAGHMATHJAXEND
      case 27: // OPENAGHNOTESTART
      case 28: // OPENAGHTHEOREMSTART
      case 29: // OPENAGHEXERCISESTART
      case 30: // OPENAGHQUOTATIONSSTART
      case 31: // OPENAGHNOTESSTART
      case 32: // OPENAGHSIMULATIONSTART
      case 33: // OPENAGHIMGFORMULASTART
      case 34: // OPENAGHCHEMEVISUALIZATIONSTART
      case 35: // XNAME
      case 36: // XANCHOR
      case 37: // XASSUMPTIONS
      case 38: // XTHESIS
      case 39: // XPROOF
      case 40: // XCONTENT
      case 41: // XSOLUTION
      case 42: // XNOTE
      case 43: // XTYPE
      case 44: // XISNUMERATION
      case 45: // XHEADLINE
      case 46: // XFILEID
      case 47: // XCAPTION
      case 48: // XFORMULATYPE
      case 49: // IMG
      case 50: // VIMEO
      case 51: // YOUTUBE
      case 52: // MEDIAPLAYER
      case 53: // SUB
      case 54: // OPENAGHQUOTATION
      case 55: // TABLEHEADSTART
      case 56: // TABLEHEADEND
      case 57: // ERRMATH
      case 58: // ERRWRSURR
      case 59: // ERRDOUBLEBR
      case 60: // ERRINVSURR
      case 61: // ERRDOUBLEDOLLAR
      case 62: // QU
      case 63: // BR
      case 64: // BL
      case 65: // NR
      case 66: // NL
      case 67: // TEXT
      case 69: // root
      case 70: // module
      case 71: // modulesimple
      case 72: // tiki
      case 73: // openagh
      case 74: // text
      case 75: // math
      case 76: // img
      case 77: // vimeo
      case 78: // youtube
      case 79: // mediaplayer
      case 80: // sub
      case 81: // openaghmathjax
      case 82: // openaghlemma
      case 83: // openaghdefinition
      case 84: // openaghexample
      case 85: // openaghlaw
      case 86: // openaghrule
      case 87: // openaghconclusion
      case 88: // openaghderivation
      case 89: // openaghsummary
      case 90: // openaghinformation
      case 91: // openaghannotation
      case 92: // openaghproperty
      case 94: // openaghquotations
      case 95: // openaghnote
      case 96: // openaghnotes
      case 97: // openaghsimulation
      case 98: // openaghtheorem
      case 99: // openaghexercise
      case 100: // openaghimgformula
      case 101: // openaghchemevisualization
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    // that is emptied.
    that.type = empty_symbol;
  }

  inline
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
      switch (that.type_get ())
    {
      case 102: // xopenaghmathjaxattrs
      case 103: // xopenaghtheoremattrs
      case 104: // xopenaghexerciseattrs
      case 105: // xopenaghimgformulaattrs
      case 106: // x_name_anchor
        value.copy< std::map<std::string, std::string> > (that.value);
        break;

      case 107: // xname
      case 108: // xanchor
      case 109: // xisnumeration
      case 110: // xtype
      case 111: // xassumptions
      case 112: // xthesis
      case 113: // xproof
      case 114: // xcontent
      case 115: // xsolution
      case 116: // xnote
      case 117: // xheadline
      case 118: // xfileid
      case 119: // xformulatype
        value.copy< std::pair<std::string, std::string> > (that.value);
        break;

      case 3: // OPENAGHLEMMASTART
      case 4: // OPENAGHDEFINITIONSTART
      case 5: // OPENAGHEXAMPLESTART
      case 6: // OPENAGHLAWSTART
      case 7: // OPENAGHRULESTART
      case 8: // OPENAGHCONCLUSIONSTART
      case 9: // OPENAGHDERIVATIONSTART
      case 10: // OPENAGHSUMMARYSTART
      case 11: // OPENAGHINFORMATIONSTART
      case 12: // OPENAGHANNOTATIONSTART
      case 13: // OPENAGHPROPERTYSTART
      case 14: // OPENAGHMATHJAXSTART
      case 15: // OPENAGHLEMMAEND
      case 16: // OPENAGHDEFINITIONEND
      case 17: // OPENAGHEXAMPLEEND
      case 18: // OPENAGHLAWEND
      case 19: // OPENAGHRULEEND
      case 20: // OPENAGHCONCLUSIONEND
      case 21: // OPENAGHDERIVATIONEND
      case 22: // OPENAGHSUMMARYEND
      case 23: // OPENAGHINFORMATIONEND
      case 24: // OPENAGHANNOTATIONEND
      case 25: // OPENAGHPROPERTYEND
      case 26: // OPENAGHMATHJAXEND
      case 27: // OPENAGHNOTESTART
      case 28: // OPENAGHTHEOREMSTART
      case 29: // OPENAGHEXERCISESTART
      case 30: // OPENAGHQUOTATIONSSTART
      case 31: // OPENAGHNOTESSTART
      case 32: // OPENAGHSIMULATIONSTART
      case 33: // OPENAGHIMGFORMULASTART
      case 34: // OPENAGHCHEMEVISUALIZATIONSTART
      case 35: // XNAME
      case 36: // XANCHOR
      case 37: // XASSUMPTIONS
      case 38: // XTHESIS
      case 39: // XPROOF
      case 40: // XCONTENT
      case 41: // XSOLUTION
      case 42: // XNOTE
      case 43: // XTYPE
      case 44: // XISNUMERATION
      case 45: // XHEADLINE
      case 46: // XFILEID
      case 47: // XCAPTION
      case 48: // XFORMULATYPE
      case 49: // IMG
      case 50: // VIMEO
      case 51: // YOUTUBE
      case 52: // MEDIAPLAYER
      case 53: // SUB
      case 54: // OPENAGHQUOTATION
      case 55: // TABLEHEADSTART
      case 56: // TABLEHEADEND
      case 57: // ERRMATH
      case 58: // ERRWRSURR
      case 59: // ERRDOUBLEBR
      case 60: // ERRINVSURR
      case 61: // ERRDOUBLEDOLLAR
      case 62: // QU
      case 63: // BR
      case 64: // BL
      case 65: // NR
      case 66: // NL
      case 67: // TEXT
      case 69: // root
      case 70: // module
      case 71: // modulesimple
      case 72: // tiki
      case 73: // openagh
      case 74: // text
      case 75: // math
      case 76: // img
      case 77: // vimeo
      case 78: // youtube
      case 79: // mediaplayer
      case 80: // sub
      case 81: // openaghmathjax
      case 82: // openaghlemma
      case 83: // openaghdefinition
      case 84: // openaghexample
      case 85: // openaghlaw
      case 86: // openaghrule
      case 87: // openaghconclusion
      case 88: // openaghderivation
      case 89: // openaghsummary
      case 90: // openaghinformation
      case 91: // openaghannotation
      case 92: // openaghproperty
      case 94: // openaghquotations
      case 95: // openaghnote
      case 96: // openaghnotes
      case 97: // openaghsimulation
      case 98: // openaghtheorem
      case 99: // openaghexercise
      case 100: // openaghimgformula
      case 101: // openaghchemevisualization
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    return *this;
  }


  template <typename Base>
  inline
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo,
                                     const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YYUSE (yyoutput);
    symbol_number_type yytype = yysym.type_get ();
    // Avoid a (spurious) G++ 4.8 warning about "array subscript is
    // below array bounds".
    if (yysym.empty ())
      std::abort ();
    yyo << (yytype < yyntokens_ ? "token" : "nterm")
        << ' ' << yytname_[yytype] << " (";
    YYUSE (yytype);
    yyo << ')';
  }
#endif

  inline
  void
  parser::yypush_ (const char* m, state_type s, symbol_type& sym)
  {
    stack_symbol_type t (s, sym);
    yypush_ (m, t);
  }

  inline
  void
  parser::yypush_ (const char* m, stack_symbol_type& s)
  {
    if (m)
      YY_SYMBOL_PRINT (m, s);
    yystack_.push (s);
  }

  inline
  void
  parser::yypop_ (unsigned int n)
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  inline parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - yyntokens_] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - yyntokens_];
  }

  inline bool
  parser::yy_pact_value_is_default_ (int yyvalue)
  {
    return yyvalue == yypact_ninf_;
  }

  inline bool
  parser::yy_table_value_is_error_ (int yyvalue)
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::parse ()
  {
    // State.
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The return value of parse ().
    int yyresult;

    // FIXME: This shoud be completely indented.  It is not yet to
    // avoid gratuitous conflicts when merging into the master branch.
    try
      {
    YYCDEBUG << "Starting parse" << std::endl;


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, yyla);

    // A new symbol was pushed on the stack.
  yynewstate:
    YYCDEBUG << "Entering state " << yystack_[0].state << std::endl;

    // Accept?
    if (yystack_[0].state == yyfinal_)
      goto yyacceptlab;

    goto yybackup;

    // Backup.
  yybackup:

    // Try to take a decision without lookahead.
    yyn = yypact_[yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token: ";
        try
          {
            symbol_type yylookahead (yylex ());
            yyla.move (yylookahead);
          }
        catch (const syntax_error& yyexc)
          {
            error (yyexc);
            goto yyerrlab1;
          }
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.type_get ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.type_get ())
      goto yydefault;

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", yyn, yyla);
    goto yynewstate;

  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;

  /*-----------------------------.
  | yyreduce -- Do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_(yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
        switch (yyr1_[yyn])
    {
      case 102: // xopenaghmathjaxattrs
      case 103: // xopenaghtheoremattrs
      case 104: // xopenaghexerciseattrs
      case 105: // xopenaghimgformulaattrs
      case 106: // x_name_anchor
        yylhs.value.build< std::map<std::string, std::string> > ();
        break;

      case 107: // xname
      case 108: // xanchor
      case 109: // xisnumeration
      case 110: // xtype
      case 111: // xassumptions
      case 112: // xthesis
      case 113: // xproof
      case 114: // xcontent
      case 115: // xsolution
      case 116: // xnote
      case 117: // xheadline
      case 118: // xfileid
      case 119: // xformulatype
        yylhs.value.build< std::pair<std::string, std::string> > ();
        break;

      case 3: // OPENAGHLEMMASTART
      case 4: // OPENAGHDEFINITIONSTART
      case 5: // OPENAGHEXAMPLESTART
      case 6: // OPENAGHLAWSTART
      case 7: // OPENAGHRULESTART
      case 8: // OPENAGHCONCLUSIONSTART
      case 9: // OPENAGHDERIVATIONSTART
      case 10: // OPENAGHSUMMARYSTART
      case 11: // OPENAGHINFORMATIONSTART
      case 12: // OPENAGHANNOTATIONSTART
      case 13: // OPENAGHPROPERTYSTART
      case 14: // OPENAGHMATHJAXSTART
      case 15: // OPENAGHLEMMAEND
      case 16: // OPENAGHDEFINITIONEND
      case 17: // OPENAGHEXAMPLEEND
      case 18: // OPENAGHLAWEND
      case 19: // OPENAGHRULEEND
      case 20: // OPENAGHCONCLUSIONEND
      case 21: // OPENAGHDERIVATIONEND
      case 22: // OPENAGHSUMMARYEND
      case 23: // OPENAGHINFORMATIONEND
      case 24: // OPENAGHANNOTATIONEND
      case 25: // OPENAGHPROPERTYEND
      case 26: // OPENAGHMATHJAXEND
      case 27: // OPENAGHNOTESTART
      case 28: // OPENAGHTHEOREMSTART
      case 29: // OPENAGHEXERCISESTART
      case 30: // OPENAGHQUOTATIONSSTART
      case 31: // OPENAGHNOTESSTART
      case 32: // OPENAGHSIMULATIONSTART
      case 33: // OPENAGHIMGFORMULASTART
      case 34: // OPENAGHCHEMEVISUALIZATIONSTART
      case 35: // XNAME
      case 36: // XANCHOR
      case 37: // XASSUMPTIONS
      case 38: // XTHESIS
      case 39: // XPROOF
      case 40: // XCONTENT
      case 41: // XSOLUTION
      case 42: // XNOTE
      case 43: // XTYPE
      case 44: // XISNUMERATION
      case 45: // XHEADLINE
      case 46: // XFILEID
      case 47: // XCAPTION
      case 48: // XFORMULATYPE
      case 49: // IMG
      case 50: // VIMEO
      case 51: // YOUTUBE
      case 52: // MEDIAPLAYER
      case 53: // SUB
      case 54: // OPENAGHQUOTATION
      case 55: // TABLEHEADSTART
      case 56: // TABLEHEADEND
      case 57: // ERRMATH
      case 58: // ERRWRSURR
      case 59: // ERRDOUBLEBR
      case 60: // ERRINVSURR
      case 61: // ERRDOUBLEDOLLAR
      case 62: // QU
      case 63: // BR
      case 64: // BL
      case 65: // NR
      case 66: // NL
      case 67: // TEXT
      case 69: // root
      case 70: // module
      case 71: // modulesimple
      case 72: // tiki
      case 73: // openagh
      case 74: // text
      case 75: // math
      case 76: // img
      case 77: // vimeo
      case 78: // youtube
      case 79: // mediaplayer
      case 80: // sub
      case 81: // openaghmathjax
      case 82: // openaghlemma
      case 83: // openaghdefinition
      case 84: // openaghexample
      case 85: // openaghlaw
      case 86: // openaghrule
      case 87: // openaghconclusion
      case 88: // openaghderivation
      case 89: // openaghsummary
      case 90: // openaghinformation
      case 91: // openaghannotation
      case 92: // openaghproperty
      case 94: // openaghquotations
      case 95: // openaghnote
      case 96: // openaghnotes
      case 97: // openaghsimulation
      case 98: // openaghtheorem
      case 99: // openaghexercise
      case 100: // openaghimgformula
      case 101: // openaghchemevisualization
        yylhs.value.build< std::string > ();
        break;

      default:
        break;
    }



      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
      try
        {
          switch (yyn)
            {
  case 2:
#line 124 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); process_module(yylhs.value.as< std::string > ()); }
#line 831 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 3:
#line 128 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 837 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 4:
#line 129 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 843 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 5:
#line 130 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 849 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 6:
#line 131 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 855 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 7:
#line 132 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 861 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 8:
#line 133 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 867 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 9:
#line 134 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 873 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 12:
#line 137 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 879 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 13:
#line 138 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 885 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 16:
#line 144 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 891 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 17:
#line 145 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 897 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 18:
#line 146 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 903 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 19:
#line 147 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 909 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 20:
#line 148 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[2].value.as< std::string > () + yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 915 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 26:
#line 160 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 921 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 27:
#line 161 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 927 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 28:
#line 162 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 933 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 29:
#line 163 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 939 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 30:
#line 164 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 945 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 31:
#line 165 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 951 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 32:
#line 166 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 957 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 33:
#line 167 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 963 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 34:
#line 168 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 969 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 35:
#line 169 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 975 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 36:
#line 170 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 981 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 38:
#line 172 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 987 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 39:
#line 173 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 993 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 40:
#line 174 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 999 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 41:
#line 175 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1005 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 42:
#line 176 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1011 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 43:
#line 177 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1017 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 44:
#line 178 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1023 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 45:
#line 179 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1029 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 46:
#line 183 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1035 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 47:
#line 187 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1041 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 48:
#line 188 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1047 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 49:
#line 189 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[0].value.as< std::string > (); }
#line 1053 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 50:
#line 190 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[2].value.as< std::string > () + yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 1059 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 51:
#line 191 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = yystack_[1].value.as< std::string > () + yystack_[0].value.as< std::string > (); }
#line 1065 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 52:
#line 192 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = ""; }
#line 1071 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 53:
#line 200 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = ""; }
#line 1077 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 54:
#line 204 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = ""; }
#line 1083 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 55:
#line 208 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = ""; }
#line 1089 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 56:
#line 212 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = ""; }
#line 1095 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 57:
#line 216 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = ""; }
#line 1101 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 58:
#line 223 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div_openaghmathjax(yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1107 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 59:
#line 226 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghlemma", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1113 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 60:
#line 229 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghdefinition", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1119 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 61:
#line 232 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghexample", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1125 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 62:
#line 235 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghlaw", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1131 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 63:
#line 238 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghrule", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1137 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 64:
#line 241 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghconclusion", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1143 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 65:
#line 244 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghderivation", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1149 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 66:
#line 247 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghsummary", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1155 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 67:
#line 250 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghinformation", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1161 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 68:
#line 253 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghannotation", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1167 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 69:
#line 256 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghproperty", yystack_[4].value.as< std::map<std::string, std::string> > (), yystack_[1].value.as< std::string > ()); }
#line 1173 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 71:
#line 267 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghquotations", { yystack_[1].value.as< std::pair<std::string, std::string> > () }); }
#line 1179 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 72:
#line 271 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghnote", { yystack_[1].value.as< std::pair<std::string, std::string> > () }); }
#line 1185 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 73:
#line 275 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghnotes", { yystack_[1].value.as< std::pair<std::string, std::string> > () }); }
#line 1191 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 74:
#line 279 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghsimulation", { yystack_[1].value.as< std::pair<std::string, std::string> > () }); }
#line 1197 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 75:
#line 283 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghtheorem", { yystack_[1].value.as< std::map<std::string, std::string> > () }); }
#line 1203 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 76:
#line 287 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghexercise", { yystack_[1].value.as< std::map<std::string, std::string> > () }); }
#line 1209 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 77:
#line 291 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghimgformula", { yystack_[1].value.as< std::map<std::string, std::string> > () }); }
#line 1215 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 78:
#line 295 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::string > () = div("openaghchemevisualization", { yystack_[1].value.as< std::pair<std::string, std::string> > () }); }
#line 1221 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 79:
#line 306 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1227 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 80:
#line 307 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1233 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 81:
#line 308 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1239 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 82:
#line 309 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1245 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 83:
#line 310 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1251 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 84:
#line 311 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1257 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 85:
#line 324 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1263 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 86:
#line 325 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1269 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 87:
#line 326 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1275 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 88:
#line 327 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1281 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 89:
#line 328 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1287 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 90:
#line 329 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1293 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 91:
#line 330 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1299 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 92:
#line 331 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1305 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 93:
#line 332 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1311 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 94:
#line 333 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1317 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 95:
#line 334 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1323 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 96:
#line 335 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1329 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 97:
#line 336 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1335 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 98:
#line 337 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1341 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 99:
#line 338 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1347 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 100:
#line 339 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1353 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 101:
#line 340 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1359 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 102:
#line 341 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1365 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 103:
#line 342 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1371 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 104:
#line 343 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1377 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 105:
#line 344 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1383 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 106:
#line 345 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1389 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 107:
#line 346 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1395 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 108:
#line 347 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1401 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 109:
#line 348 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1407 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 110:
#line 349 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1413 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 111:
#line 350 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1419 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 112:
#line 351 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1425 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 113:
#line 352 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1431 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 114:
#line 353 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1437 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 115:
#line 354 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1443 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 116:
#line 355 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1449 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 117:
#line 356 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1455 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 118:
#line 357 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1461 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 119:
#line 358 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1467 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 120:
#line 359 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1473 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 121:
#line 360 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1479 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 122:
#line 361 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1485 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 123:
#line 362 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1491 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 124:
#line 363 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1497 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 125:
#line 364 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1503 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 126:
#line 365 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1509 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 127:
#line 366 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1515 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 128:
#line 367 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1521 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 129:
#line 368 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1527 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 130:
#line 369 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1533 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 131:
#line 370 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1539 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 132:
#line 371 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1545 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 133:
#line 372 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1551 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 134:
#line 373 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1557 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 135:
#line 374 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1563 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 136:
#line 375 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1569 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 137:
#line 376 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1575 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 138:
#line 377 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1581 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 139:
#line 378 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1587 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 140:
#line 379 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1593 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 141:
#line 380 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1599 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 142:
#line 381 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1605 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 143:
#line 382 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1611 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 144:
#line 383 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1617 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 145:
#line 384 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1623 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 146:
#line 385 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1629 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 147:
#line 386 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1635 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 148:
#line 387 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1641 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 149:
#line 388 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1647 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 150:
#line 389 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1653 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 151:
#line 390 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1659 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 152:
#line 391 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1665 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 153:
#line 392 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1671 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 154:
#line 393 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1677 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 155:
#line 394 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1683 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 156:
#line 395 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1689 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 157:
#line 396 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1695 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 158:
#line 397 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1701 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 159:
#line 398 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1707 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 160:
#line 399 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1713 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 161:
#line 400 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1719 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 162:
#line 401 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1725 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 163:
#line 402 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1731 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 164:
#line 403 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1737 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 165:
#line 404 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1743 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 166:
#line 405 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1749 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 167:
#line 406 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1755 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 168:
#line 407 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1761 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 169:
#line 408 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1767 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 170:
#line 409 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1773 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 171:
#line 410 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1779 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 172:
#line 411 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1785 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 173:
#line 412 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1791 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 174:
#line 413 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1797 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 175:
#line 414 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1803 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 176:
#line 415 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1809 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 177:
#line 416 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1815 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 178:
#line 417 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1821 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 179:
#line 418 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1827 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 180:
#line 419 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1833 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 181:
#line 420 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1839 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 182:
#line 421 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1845 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 183:
#line 422 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1851 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 184:
#line 423 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1857 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 185:
#line 424 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1863 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 186:
#line 425 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1869 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 187:
#line 426 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1875 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 188:
#line 427 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1881 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 189:
#line 428 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1887 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 190:
#line 429 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1893 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 191:
#line 430 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1899 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 192:
#line 431 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1905 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 193:
#line 432 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1911 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 194:
#line 433 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1917 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 195:
#line 434 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1923 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 196:
#line 435 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1929 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 197:
#line 436 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1935 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 198:
#line 437 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1941 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 199:
#line 438 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1947 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 200:
#line 439 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1953 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 201:
#line 440 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1959 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 202:
#line 441 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1965 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 203:
#line 442 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1971 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 204:
#line 443 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[4].value.as< std::pair<std::string, std::string> > (), yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1977 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 205:
#line 455 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1983 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 206:
#line 456 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1989 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 207:
#line 457 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 1995 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 208:
#line 458 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2001 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 209:
#line 459 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2007 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 210:
#line 460 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2013 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 211:
#line 461 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2019 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 212:
#line 462 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2025 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 213:
#line 463 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2031 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 214:
#line 464 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2037 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 215:
#line 465 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2043 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 216:
#line 466 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2049 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 217:
#line 467 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2055 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 218:
#line 468 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2061 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 219:
#line 469 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2067 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 220:
#line 470 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2073 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 221:
#line 471 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2079 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 222:
#line 472 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2085 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 223:
#line 473 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2091 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 224:
#line 474 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2097 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 225:
#line 475 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2103 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 226:
#line 476 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2109 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 227:
#line 477 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2115 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 228:
#line 478 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2121 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 229:
#line 482 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2127 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 230:
#line 483 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2133 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 231:
#line 484 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2139 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 232:
#line 485 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2145 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 233:
#line 486 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2151 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 234:
#line 487 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2157 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 235:
#line 488 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2163 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 236:
#line 489 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2169 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 237:
#line 490 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2175 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 238:
#line 491 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2181 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 239:
#line 492 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2187 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 240:
#line 493 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2193 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 241:
#line 494 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2199 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 242:
#line 495 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2205 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 243:
#line 496 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2211 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 244:
#line 497 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2217 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 245:
#line 498 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2223 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 246:
#line 499 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2229 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 247:
#line 500 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2235 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 248:
#line 501 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2241 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 249:
#line 502 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2247 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 250:
#line 503 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2253 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 251:
#line 504 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2259 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 252:
#line 505 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[3].value.as< std::pair<std::string, std::string> > (), yystack_[2].value.as< std::pair<std::string, std::string> > (), yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2265 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 253:
#line 515 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2271 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 254:
#line 516 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::map<std::string, std::string> > () = {yystack_[1].value.as< std::pair<std::string, std::string> > (), yystack_[0].value.as< std::pair<std::string, std::string> > ()}; }
#line 2277 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 255:
#line 524 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"name", yystack_[1].value.as< std::string > ()}; }
#line 2283 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 256:
#line 525 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"name", ""}; }
#line 2289 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 257:
#line 526 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"name", ""}; }
#line 2295 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 258:
#line 530 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"anchor", yystack_[1].value.as< std::string > ()}; }
#line 2301 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 259:
#line 531 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"anchor", ""}; }
#line 2307 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 260:
#line 532 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"anchor", ""}; }
#line 2313 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 261:
#line 536 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"isnumeration", yystack_[1].value.as< std::string > ()}; }
#line 2319 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 262:
#line 537 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"isnumeration", ""}; }
#line 2325 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 263:
#line 538 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"isnumeration", ""}; }
#line 2331 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 264:
#line 542 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"type", yystack_[1].value.as< std::string > ()}; }
#line 2337 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 265:
#line 543 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"type", ""}; }
#line 2343 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 266:
#line 544 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"type", ""}; }
#line 2349 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 267:
#line 548 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"assumptions", yystack_[1].value.as< std::string > ()}; }
#line 2355 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 268:
#line 549 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"assumptions", ""}; }
#line 2361 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 269:
#line 550 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"assumptions", ""}; }
#line 2367 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 270:
#line 554 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"thesis", yystack_[1].value.as< std::string > ()}; }
#line 2373 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 271:
#line 555 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"thesis", ""}; }
#line 2379 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 272:
#line 556 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"thesis", ""}; }
#line 2385 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 273:
#line 560 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"proof", yystack_[1].value.as< std::string > ()}; }
#line 2391 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 274:
#line 561 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"proof", ""}; }
#line 2397 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 275:
#line 562 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"proof", ""}; }
#line 2403 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 276:
#line 566 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"content", yystack_[1].value.as< std::string > ()}; }
#line 2409 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 277:
#line 567 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"content", ""}; }
#line 2415 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 278:
#line 568 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"content", ""}; }
#line 2421 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 279:
#line 572 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"solution", yystack_[1].value.as< std::string > ()}; }
#line 2427 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 280:
#line 573 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"solution", ""}; }
#line 2433 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 281:
#line 574 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"solution", ""}; }
#line 2439 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 282:
#line 578 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"note", yystack_[1].value.as< std::string > ()}; }
#line 2445 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 283:
#line 579 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"note", ""}; }
#line 2451 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 284:
#line 580 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"note", ""}; }
#line 2457 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 285:
#line 584 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"headline", yystack_[1].value.as< std::string > ()}; }
#line 2463 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 286:
#line 585 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"headline", ""}; }
#line 2469 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 287:
#line 586 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"headline", ""}; }
#line 2475 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 288:
#line 590 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"fileId", yystack_[1].value.as< std::string > ()}; }
#line 2481 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 289:
#line 591 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"fileId", ""}; }
#line 2487 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 290:
#line 592 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"fileId", ""}; }
#line 2493 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 291:
#line 596 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"formulaType", yystack_[1].value.as< std::string > ()}; }
#line 2499 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 292:
#line 597 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"formulaType", ""}; }
#line 2505 "gen/parser.tab.cc" // lalr1.cc:859
    break;

  case 293:
#line 598 "src/parser.yy" // lalr1.cc:859
    { yylhs.value.as< std::pair<std::string, std::string> > () = {"formulaType", ""}; }
#line 2511 "gen/parser.tab.cc" // lalr1.cc:859
    break;


#line 2515 "gen/parser.tab.cc" // lalr1.cc:859
            default:
              break;
            }
        }
      catch (const syntax_error& yyexc)
        {
          error (yyexc);
          YYERROR;
        }
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;
      YY_STACK_PRINT ();

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, yylhs);
    }
    goto yynewstate;

  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        error (yysyntax_error_ (yystack_[0].state, yyla));
      }


    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.type_get () == yyeof_)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:

    /* Pacify compilers like GCC when the user code never invokes
       YYERROR and the label yyerrorlab therefore never appears in user
       code.  */
    if (false)
      goto yyerrorlab;
    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    goto yyerrlab1;

  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    {
      stack_symbol_type error_token;
      for (;;)
        {
          yyn = yypact_[yystack_[0].state];
          if (!yy_pact_value_is_default_ (yyn))
            {
              yyn += yyterror_;
              if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yyterror_)
                {
                  yyn = yytable_[yyn];
                  if (0 < yyn)
                    break;
                }
            }

          // Pop the current state because it cannot handle the error token.
          if (yystack_.size () == 1)
            YYABORT;

          yy_destroy_ ("Error: popping", yystack_[0]);
          yypop_ ();
          YY_STACK_PRINT ();
        }


      // Shift the error token.
      error_token.state = yyn;
      yypush_ ("Shifting", error_token);
    }
    goto yynewstate;

    // Accept.
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;

    // Abort.
  yyabortlab:
    yyresult = 1;
    goto yyreturn;

  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack"
                 << std::endl;
        // Do not try to display the values of the reclaimed symbols,
        // as their printer might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.what());
  }

  // Generate an error message.
  std::string
  parser::yysyntax_error_ (state_type, const symbol_type&) const
  {
    return YY_("syntax error");
  }


  const short int parser::yypact_ninf_ = -243;

  const signed char parser::yytable_ninf_ = -1;

  const short int
  parser::yypact_[] =
  {
    2313,     9,     9,     9,     9,     9,     9,     9,     9,     9,
       9,     9,    13,    68,   143,    81,    73,    73,    79,   -17,
      79,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,    -9,  -243,  -243,  -243,   165,  2378,     2,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,    -3,
      -2,    72,   178,   138,   170,   190,   196,   199,   205,   209,
     220,   234,   237,   240,   -25,   -24,   248,   158,    63,    69,
      -1,   247,  2443,  2508,  2573,   254,   186,   182,   193,   154,
     242,  2638,  2703,   261,    95,    92,   115,   126,     0,   281,
     282,     1,   287,    67,   290,   111,   -18,     3,   -26,   299,
       8,  -243,  -243,  -243,     2,  -243,  -243,  -243,  -243,  -243,
    -243,    -9,    10,    -9,    11,   305,  -243,  -243,   312,   315,
     317,   324,   327,   329,   332,   333,   334,   336,  -243,   340,
    -243,   342,   343,   362,   363,   362,   178,   363,   178,    -9,
      18,  -243,    -9,  2768,    -9,  2833,    -9,  2898,  -243,   321,
     214,   250,   335,   321,   195,   201,   285,   214,   195,   227,
     292,   250,   201,   227,   348,   335,   285,   292,   348,    -9,
    2963,    -9,  3028,  -243,    14,   127,   167,    14,   -14,   129,
     127,   -14,     9,   167,   129,     9,    -9,    19,  -243,  -243,
      -9,    27,  -243,  -243,   346,  -243,   -12,   124,    36,   -12,
     -13,     4,   124,   -13,    63,    36,     4,    63,  -243,  -243,
    -243,  -243,  2313,  2313,  2313,  2313,  2313,  2313,  2313,  2313,
    2313,  2313,  2313,  -243,  -243,   231,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,    -9,    -9,    -9,   203,   146,   210,   203,
      65,   293,   146,    65,   245,   210,   293,   245,   203,   146,
     210,   203,   174,   114,   146,   174,   330,   210,   114,   330,
     203,    65,   293,   203,   174,   114,    65,   174,     9,   293,
     114,     9,   146,    65,   245,   146,   174,   330,    65,   174,
       9,   245,   330,     9,   210,   293,   245,   210,   114,   330,
     293,   114,     9,   245,   330,     9,    -9,    -9,   369,   372,
     369,   178,   372,   178,   369,   372,   369,   138,   372,   138,
     369,   178,   369,   138,   178,   138,   372,   178,   372,   138,
     178,   138,  -243,  -243,  -243,   365,    79,   365,   362,    79,
     362,   365,    79,   365,   178,    79,   178,   365,   362,   365,
     178,   362,   178,    79,   362,    79,   178,   362,   178,  1598,
    1663,  1728,  1793,  1858,  1923,  1988,  2053,  2118,  2183,  2248,
     231,  -243,  -243,  -243,    26,   375,   377,   375,   379,   377,
     379,   375,   377,   375,   178,   377,   178,   375,   379,   375,
     178,   379,   178,   377,   379,   377,   178,   379,   178,   375,
     377,   375,   379,   377,   379,   375,   377,   375,   138,   377,
     138,   375,   379,   375,   138,   379,   138,   377,   379,   377,
     138,   379,   138,   375,   377,   375,   178,   377,   178,   375,
     377,   375,   138,   377,   138,   375,   178,   375,   138,   178,
     138,   377,   178,   377,   138,   178,   138,   375,   379,   375,
     178,   379,   178,   375,   379,   375,   138,   379,   138,   375,
     178,   375,   138,   178,   138,   379,   178,   379,   138,   178,
     138,   377,   379,   377,   178,   379,   178,   377,   379,   377,
     138,   379,   138,   377,   178,   377,   138,   178,   138,   379,
     178,   379,   138,   178,   138,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,   133,  -243,   231,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243
  };

  const unsigned short int
  parser::yydefact_[] =
  {
       0,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     257,   257,   260,   284,   257,   257,   287,   287,   290,   260,
     290,    53,    54,    55,    56,    57,    70,   294,   295,   296,
     297,   298,     0,     5,     3,    46,     0,     2,     8,    10,
      12,    16,    21,    22,    23,    24,    25,    18,    26,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    43,    41,    42,    44,    45,    14,     0,
       0,     0,   260,   257,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   263,   260,   260,
       0,     0,     0,     0,     0,     0,   260,   257,   257,   257,
     257,     0,     0,     0,   260,   257,   257,   257,     0,     0,
       0,     0,     0,     0,     0,   266,   260,   260,   260,     0,
       0,     1,     6,     4,     9,    11,    13,     7,    15,    17,
      19,   256,     0,   259,     0,     0,   253,   254,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   265,     0,
     262,     0,     0,   266,   263,   266,   260,   263,   260,   283,
       0,    72,   268,     0,   271,     0,   274,     0,    75,   269,
     260,   260,   260,   269,   257,   257,   257,   260,   257,   257,
     257,   260,   257,   257,   257,   260,   257,   257,   257,   277,
       0,   280,     0,    76,   278,   260,   260,   278,   257,   257,
     260,   257,   257,   260,   257,   257,   286,     0,    71,    73,
     289,     0,    74,   292,     0,    77,   290,   266,   266,   290,
     260,   260,   266,   260,   260,   266,   260,   260,    78,    20,
     255,   258,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   264,   261,    52,    84,    82,    80,    79,
      81,    83,   282,   267,   270,   273,   272,   269,   269,   272,
     260,   260,   269,   260,   260,   269,   260,   260,   272,   269,
     269,   272,   257,   257,   269,   257,   257,   269,   257,   257,
     272,   260,   260,   272,   257,   257,   260,   257,   257,   260,
     257,   257,   269,   260,   260,   269,   257,   257,   260,   257,
     257,   260,   257,   257,   269,   260,   260,   269,   257,   257,
     260,   257,   257,   260,   257,   257,   276,   279,   281,   278,
     281,   260,   278,   260,   281,   278,   281,   257,   278,   257,
     281,   260,   281,   257,   260,   257,   278,   260,   278,   257,
     260,   257,   285,   288,   291,   293,   290,   293,   266,   290,
     266,   293,   290,   293,   260,   290,   260,   293,   266,   293,
     260,   266,   260,   290,   266,   290,   260,   266,   260,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      52,    49,    48,    47,     0,   275,   272,   275,   269,   272,
     269,   275,   272,   275,   260,   272,   260,   275,   269,   275,
     260,   269,   260,   272,   269,   272,   260,   269,   260,   275,
     272,   275,   269,   272,   269,   275,   272,   275,   257,   272,
     257,   275,   269,   275,   257,   269,   257,   272,   269,   272,
     257,   269,   257,   275,   272,   275,   260,   272,   260,   275,
     272,   275,   257,   272,   257,   275,   260,   275,   257,   260,
     257,   272,   260,   272,   257,   260,   257,   275,   269,   275,
     260,   269,   260,   275,   269,   275,   257,   269,   257,   275,
     260,   275,   257,   260,   257,   269,   260,   269,   257,   260,
     257,   272,   269,   272,   260,   269,   260,   272,   269,   272,
     257,   269,   257,   272,   260,   272,   257,   260,   257,   269,
     260,   269,   257,   260,   257,   205,   206,   207,   208,   209,
     210,   212,   211,   214,   213,   216,   215,   217,   218,   219,
     220,   221,   222,   224,   223,   226,   225,   228,   227,   248,
     247,   250,   249,   252,   251,   233,   234,   230,   229,   232,
     231,   240,   239,   235,   236,   237,   238,   245,   246,   242,
     241,   244,   243,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,     0,    58,    51,    85,    86,    87,
      88,    89,    90,    92,    91,    94,    93,    96,    95,    97,
      98,    99,   100,   101,   102,   104,   103,   106,   105,   108,
     107,   112,   111,   114,   113,   109,   110,   117,   118,   119,
     120,   116,   115,   124,   123,   126,   125,   121,   122,   129,
     130,   131,   132,   128,   127,   137,   138,   134,   133,   136,
     135,   144,   143,   139,   140,   141,   142,   149,   150,   146,
     145,   148,   147,   156,   155,   151,   152,   153,   154,   157,
     158,   159,   160,   161,   162,   164,   163,   166,   165,   168,
     167,   169,   170,   171,   172,   173,   174,   176,   175,   178,
     177,   180,   179,   184,   183,   186,   185,   181,   182,   189,
     190,   191,   192,   188,   187,   196,   195,   198,   197,   193,
     194,   201,   202,   203,   204,   200,   199,    50
  };

  const short int
  parser::yypgoto_[] =
  {
    -243,  -243,   429,   448,   309,   427,   -37,  -242,  -243,  -243,
    -243,  -243,  -243,   -36,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,
    -243,  -243,  -243,  -243,  -243,  -243,  -243,  -243,   137,   447,
      88,   -83,   139,   784,   844,  1129,  1148,   106,  -243,   400,
     100,  -108,   618
  };

  const short int
  parser::yydefgoto_[] =
  {
      -1,    36,    37,    38,    39,    40,    41,   566,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    86,    95,   103,   114,    71,    72,
      73,    88,    89,    98,    99,   100,   106,   107,    91,   109,
     112,   118,    68
  };

  const unsigned short int
  parser::yytable_[] =
  {
     127,   129,   130,   384,   153,    12,   158,   218,   221,   224,
      70,    12,    12,    12,    12,    12,    12,    84,    70,    70,
     111,    69,    12,    70,    12,    12,    84,   102,   111,   111,
     113,   113,    12,    12,   111,   113,   113,   148,   150,    70,
      70,    12,    35,    35,    69,    70,    84,   149,   151,    70,
     111,   113,   565,    32,   101,   102,    84,    85,    35,   131,
     133,   159,   206,   210,    35,    35,    35,    35,    35,    35,
     229,   247,   230,   231,   250,    35,   214,    35,    35,    84,
     252,   342,   111,   129,   130,    35,    35,   129,   130,   343,
     380,   381,   382,    35,    35,   129,   130,   129,   130,    70,
      87,    70,    97,   105,    94,    70,    84,   115,   346,   348,
      90,   352,   354,    85,   358,   360,    69,    70,   108,   117,
     119,   101,   102,   129,   130,   111,   127,    69,   127,   213,
     127,    70,   101,   102,    35,   101,   102,   135,   564,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    69,
      69,    70,    93,   127,    84,   127,   102,   111,   116,   113,
     136,    69,    70,    70,    69,   121,   101,    84,   102,   101,
     129,   130,   113,    69,   129,   130,   155,   157,    69,    70,
      92,    93,    94,    92,   169,    94,   178,   182,   186,    69,
      70,    92,   194,    94,   201,   204,   687,   380,   381,   382,
      35,    84,    85,    70,   219,   222,   225,   101,   383,    69,
     196,   199,   202,    94,    70,   217,   220,    69,   227,    92,
      93,    94,    70,    92,    93,    94,   154,   156,    69,    70,
      69,    93,    94,    93,    94,   138,    69,   529,    92,   531,
      94,    93,    94,   535,   249,   537,   251,    92,    93,   541,
      70,   543,    93,    94,   216,   139,   223,   226,   259,   262,
     265,   140,    69,    70,   141,   280,    94,   287,   290,   292,
     142,   299,   302,   304,   143,   311,   314,    69,    70,    92,
      93,    70,    92,   320,   322,   144,    70,    92,   330,    94,
     335,   336,   246,   341,   248,   380,   381,   382,    35,   145,
     319,   321,   146,   325,   327,   147,   331,   333,   353,   355,
     161,   359,   361,   152,   365,   367,   345,   168,   350,   351,
      69,   356,    92,    93,   193,   364,   366,    69,    70,    70,
      93,    93,   127,   127,   127,   127,   127,   127,   127,   127,
     127,   127,   127,   383,   208,   209,   125,   383,   393,   395,
     212,   399,   401,   215,   405,   407,   347,   349,    92,    93,
      94,   357,   228,   362,   363,    69,   368,    92,   232,   435,
     437,    70,    92,    93,   445,   233,   450,   451,   234,   456,
     235,   459,   461,    69,    70,    92,   469,   236,   474,   475,
     237,   480,   238,   483,   485,   239,   240,   241,   493,   242,
     498,   499,   243,   504,   244,    84,   245,    85,   344,   508,
     102,   510,   101,   113,    94,    93,    92,   110,     0,   518,
       0,     0,   521,     0,   505,   524,   507,     0,   527,     0,
     511,     0,   513,     0,     0,     0,   517,     0,   519,     0,
       0,     0,   538,     0,   540,     0,   530,     0,   544,   533,
     546,     0,   536,     0,   550,   539,   552,     0,     0,     0,
       0,    96,   104,   547,   126,   549,     0,     0,     0,     0,
       0,     0,   125,     0,   125,     0,   125,     0,     0,     0,
     120,     0,   576,     0,   578,   124,     0,   532,   582,   534,
     584,     0,     0,     0,   588,     0,   590,   542,     0,   125,
     545,   125,     0,   548,     0,     0,   551,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   132,   134,     0,
     137,   163,   165,   167,   618,     0,   620,   383,     0,   383,
     190,   192,     0,     0,   628,     0,     0,   631,   160,     0,
     634,     0,     0,   637,   173,   177,   181,   185,   642,     0,
     644,     0,   197,   200,   203,     0,   207,     0,   652,   211,
       0,   655,     0,     0,   658,     0,     0,   661,     0,     0,
       0,     0,   666,     0,   668,     0,     0,     0,     0,   120,
       0,   120,   676,     0,     0,   679,     0,     0,   682,     0,
     126,   685,   126,     0,   126,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   120,     0,     0,
     120,   124,   120,   124,   120,   124,     0,   126,     0,   126,
       0,   271,   274,   277,     0,   283,   286,   289,     0,   295,
     298,   301,     0,   307,   310,   313,     0,   120,   124,   120,
     124,     0,     0,     0,     0,   326,   328,     0,   332,   334,
       0,   338,   340,     0,   120,   128,     0,     0,   120,     0,
       0,   369,   370,   371,   372,   373,   374,   375,   376,   377,
     378,   379,     0,     0,     0,     0,     0,     0,   125,   125,
     125,   125,   125,   125,   125,   125,   125,   125,   125,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   120,   120,   120,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   417,
     419,     0,   423,   425,     0,   429,   431,     0,     0,     0,
       0,   441,   443,     0,   447,   449,     0,   453,   455,     0,
       0,     0,     0,   465,   467,     0,   471,   473,     0,   477,
     479,     0,     0,     0,     0,   489,   491,     0,   495,   497,
       0,   501,   503,     0,   120,   120,     0,     0,     0,     0,
       0,     0,     0,     0,   514,     0,   516,     0,     0,     0,
     520,   128,   522,   128,     0,   128,   526,     0,   528,     0,
       0,     0,     0,     0,     0,     0,   126,   126,   126,   126,
     126,   126,   126,   126,   126,   126,   126,     0,   128,     0,
     128,     0,     0,     0,     0,     0,     0,   124,   124,   124,
     124,   124,   124,   124,   124,   124,   124,   124,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   600,     0,   602,     0,     0,
       0,   606,     0,   608,     0,     0,     0,   612,     0,   614,
     170,   174,     0,   183,   187,     0,     0,     0,     0,   624,
       0,   626,     0,     0,     0,   630,     0,   632,     0,     0,
       0,   636,     0,   638,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   648,     0,   650,     0,     0,     0,   654,
       0,   656,     0,     0,     0,   660,     0,   662,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   672,     0,   674,
     171,   175,   179,   678,   188,   680,     0,     0,     0,   684,
       0,   686,     0,   256,     0,   263,   266,   268,     0,   275,
     278,     0,     0,     0,     0,   293,   296,     0,   303,   305,
     308,     0,   315,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   128,   128,   128,
     128,   128,   128,   128,   128,   128,   128,   128,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   257,   260,     0,   267,   269,   272,     0,
     279,   281,   284,     0,   291,     0,     0,     0,     0,   306,
     309,   312,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   387,   389,     0,     0,     0,   397,     0,   402,   403,
       0,   408,     0,   411,   413,     0,     0,     0,   421,     0,
     426,   427,     0,   432,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   457,     0,   462,   463,
       0,   468,     0,     0,     0,   476,   478,     0,   481,     0,
     486,   487,     0,   492,     0,     0,     0,   500,   502,     0,
     385,     0,   390,   391,     0,   396,     0,     0,     0,   404,
     406,     0,   409,     0,   414,   415,     0,   420,     0,     0,
       0,   428,   430,     0,   433,     0,   438,   439,     0,   444,
       0,     0,     0,   452,   454,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   482,   484,
       0,   488,   490,     0,   494,   496,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   570,     0,   572,     0,     0,     0,     0,     0,
       0,     0,   580,     0,     0,   583,     0,     0,   586,     0,
       0,   589,     0,     0,     0,     0,   594,     0,   596,     0,
       0,     0,     0,     0,     0,     0,   604,     0,     0,   607,
       0,     0,   610,     0,     0,   613,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   172,   176,   180,   184,     0,
     568,     0,     0,   571,     0,     0,   574,     0,     0,   577,
       0,     0,   640,     0,     0,   643,     0,   585,   646,   587,
       0,   649,   195,   198,   592,   205,     0,   595,     0,   657,
     598,   659,     0,   601,     0,     0,   664,     0,     0,   667,
       0,   609,   670,   611,     0,   673,     0,     0,   616,     0,
       0,   619,     0,   681,   622,   683,     0,   625,     0,     0,
       0,     0,     0,     0,     0,   633,     0,   635,   258,   261,
     264,     0,   270,   273,   276,     0,   282,   285,   288,     0,
     294,   297,   300,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   663,     0,   665,     0,     0,
       0,   669,     0,   671,     0,     0,     0,   675,     0,   677,
       0,     0,   318,     0,   323,   324,     0,   329,     0,     0,
       0,   337,   339,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   386,   388,     0,   392,   394,
       0,   398,   400,     0,     0,     0,     0,   410,   412,     0,
     416,   418,     0,   422,   424,     0,     0,     0,     0,   434,
     436,     0,   440,   442,     0,   446,   448,     0,     0,     0,
       0,   458,   460,     0,   464,   466,     0,   470,   472,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   506,     0,     0,
     509,     0,     0,   512,     0,     0,   515,     0,     0,     0,
       0,     0,     0,     0,   523,     0,   525,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   567,     0,   569,     0,     0,     0,
     573,     0,   575,     0,     0,     0,   579,     0,   581,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   591,     0,
     593,     0,     0,     0,   597,     0,   599,     0,     0,     0,
     603,     0,   605,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   615,     0,   617,     0,     0,     0,   621,     0,
     623,     0,     0,     0,   627,     0,   629,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   639,     0,   641,     0,
       0,     0,   645,     0,   647,     0,     0,     0,   651,     0,
     653,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,   553,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
      32,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,   554,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,    32,     0,     0,   122,   123,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,   555,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
      32,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,   556,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,    32,     0,     0,   122,   123,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,   557,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
      32,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,   558,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,    32,     0,     0,   122,   123,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,   559,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
      32,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,   560,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,    32,     0,     0,   122,   123,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,   561,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
      32,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   562,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,    32,     0,     0,   122,   123,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   563,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
      32,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,    32,     0,     0,    33,    34,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
      32,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,   162,     0,     0,    33,    34,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
     164,     0,     0,    33,    34,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,   166,     0,     0,    33,    34,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
     189,     0,     0,    33,    34,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,   191,     0,     0,    33,    34,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
     253,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,   254,     0,     0,   122,   123,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
     255,     0,     0,   122,   123,    35,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      13,    14,    15,    16,    17,    18,    19,    20,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    21,    22,    23,    24,    25,    26,     0,     0,
      27,    28,    29,    30,    31,   316,     0,     0,   122,   123,
      35,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    13,    14,    15,    16,    17,
      18,    19,    20,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    21,    22,    23,
      24,    25,    26,     0,     0,    27,    28,    29,    30,    31,
     317,     0,     0,   122,   123,    35
  };

  const short int
  parser::yycheck_[] =
  {
      37,    38,    38,   245,    87,    14,    89,   115,   116,   117,
      36,    14,    14,    14,    14,    14,    14,    43,    36,    36,
      46,    35,    14,    36,    14,    14,    43,    41,    46,    46,
      48,    48,    14,    14,    46,    48,    48,    62,    62,    36,
      36,    14,    67,    67,    35,    36,    43,    84,    85,    36,
      46,    48,    26,    62,    40,    41,    43,    44,    67,    62,
      62,    62,    62,    62,    67,    67,    67,    67,    67,    67,
      62,   154,    62,    62,   157,    67,   113,    67,    67,    43,
      62,    62,    46,   120,   120,    67,    67,   124,   124,    62,
      64,    65,    66,    67,    67,   132,   132,   134,   134,    36,
      12,    36,    14,    15,    39,    36,    43,    19,   216,   217,
      42,   219,   220,    44,   222,   223,    35,    36,    45,    19,
      20,    40,    41,   160,   160,    46,   163,    35,   165,    62,
     167,    36,    40,    41,    67,    40,    41,    65,   380,     2,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    35,
      35,    36,    38,   190,    43,   192,    41,    46,    19,    48,
      72,    35,    36,    36,    35,     0,    40,    43,    41,    40,
     207,   207,    48,    35,   211,   211,    88,    89,    35,    36,
      37,    38,    39,    37,    96,    39,    98,    99,   100,    35,
      36,    37,   104,    39,   106,   107,    63,    64,    65,    66,
      67,    43,    44,    36,   116,   117,   118,    40,   245,    35,
     104,   105,   106,    39,    36,   115,   116,    35,   118,    37,
      38,    39,    36,    37,    38,    39,    87,    88,    35,    36,
      35,    38,    39,    38,    39,    65,    35,   345,    37,   347,
      39,    38,    39,   351,   156,   353,   158,    37,    38,   357,
      36,   359,    38,    39,   115,    65,   117,   118,   170,   171,
     172,    65,    35,    36,    65,   177,    39,   179,   180,   181,
      65,   183,   184,   185,    65,   187,   188,    35,    36,    37,
      38,    36,    37,   195,   196,    65,    36,    37,   200,    39,
     202,   203,   153,   205,   155,    64,    65,    66,    67,    65,
     194,   195,    65,   197,   198,    65,   200,   201,   220,   221,
      63,   223,   224,    65,   226,   227,   216,    63,   218,   219,
      35,   221,    37,    38,    63,   225,   226,    35,    36,    36,
      38,    38,   369,   370,   371,   372,   373,   374,   375,   376,
     377,   378,   379,   380,    63,    63,    37,   384,   260,   261,
      63,   263,   264,    63,   266,   267,   217,   218,    37,    38,
      39,   222,    63,   224,   225,    35,   227,    37,    63,   281,
     282,    36,    37,    38,   286,    63,   288,   289,    63,   291,
      63,   293,   294,    35,    36,    37,   298,    63,   300,   301,
      63,   303,    63,   305,   306,    63,    63,    63,   310,    63,
     312,   313,    62,   315,    62,    43,    63,    44,    62,   321,
      41,   323,    40,    48,    39,    38,    37,    17,    -1,   331,
      -1,    -1,   334,    -1,   318,   337,   320,    -1,   340,    -1,
     324,    -1,   326,    -1,    -1,    -1,   330,    -1,   332,    -1,
      -1,    -1,   354,    -1,   356,    -1,   346,    -1,   360,   349,
     362,    -1,   352,    -1,   366,   355,   368,    -1,    -1,    -1,
      -1,    14,    15,   363,    37,   365,    -1,    -1,    -1,    -1,
      -1,    -1,   163,    -1,   165,    -1,   167,    -1,    -1,    -1,
      32,    -1,   394,    -1,   396,    37,    -1,   348,   400,   350,
     402,    -1,    -1,    -1,   406,    -1,   408,   358,    -1,   190,
     361,   192,    -1,   364,    -1,    -1,   367,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,    70,    -1,
      73,    92,    93,    94,   436,    -1,   438,   564,    -1,   566,
     101,   102,    -1,    -1,   446,    -1,    -1,   449,    90,    -1,
     452,    -1,    -1,   455,    97,    98,    99,   100,   460,    -1,
     462,    -1,   105,   106,   107,    -1,   108,    -1,   470,   111,
      -1,   473,    -1,    -1,   476,    -1,    -1,   479,    -1,    -1,
      -1,    -1,   484,    -1,   486,    -1,    -1,    -1,    -1,   131,
      -1,   133,   494,    -1,    -1,   497,    -1,    -1,   500,    -1,
     163,   503,   165,    -1,   167,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   159,    -1,    -1,
     162,   163,   164,   165,   166,   167,    -1,   190,    -1,   192,
      -1,   174,   175,   176,    -1,   178,   179,   180,    -1,   182,
     183,   184,    -1,   186,   187,   188,    -1,   189,   190,   191,
     192,    -1,    -1,    -1,    -1,   198,   199,    -1,   201,   202,
      -1,   204,   205,    -1,   206,    37,    -1,    -1,   210,    -1,
      -1,   232,   233,   234,   235,   236,   237,   238,   239,   240,
     241,   242,    -1,    -1,    -1,    -1,    -1,    -1,   369,   370,
     371,   372,   373,   374,   375,   376,   377,   378,   379,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   253,   254,   255,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   272,
     273,    -1,   275,   276,    -1,   278,   279,    -1,    -1,    -1,
      -1,   284,   285,    -1,   287,   288,    -1,   290,   291,    -1,
      -1,    -1,    -1,   296,   297,    -1,   299,   300,    -1,   302,
     303,    -1,    -1,    -1,    -1,   308,   309,    -1,   311,   312,
      -1,   314,   315,    -1,   316,   317,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   327,    -1,   329,    -1,    -1,    -1,
     333,   163,   335,   165,    -1,   167,   339,    -1,   341,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   369,   370,   371,   372,
     373,   374,   375,   376,   377,   378,   379,    -1,   190,    -1,
     192,    -1,    -1,    -1,    -1,    -1,    -1,   369,   370,   371,
     372,   373,   374,   375,   376,   377,   378,   379,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   418,    -1,   420,    -1,    -1,
      -1,   424,    -1,   426,    -1,    -1,    -1,   430,    -1,   432,
      96,    97,    -1,    99,   100,    -1,    -1,    -1,    -1,   442,
      -1,   444,    -1,    -1,    -1,   448,    -1,   450,    -1,    -1,
      -1,   454,    -1,   456,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   466,    -1,   468,    -1,    -1,    -1,   472,
      -1,   474,    -1,    -1,    -1,   478,    -1,   480,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   490,    -1,   492,
      96,    97,    98,   496,   100,   498,    -1,    -1,    -1,   502,
      -1,   504,    -1,   169,    -1,   171,   172,   173,    -1,   175,
     176,    -1,    -1,    -1,    -1,   181,   182,    -1,   184,   185,
     186,    -1,   188,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   369,   370,   371,
     372,   373,   374,   375,   376,   377,   378,   379,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   169,   170,    -1,   172,   173,   174,    -1,
     176,   177,   178,    -1,   180,    -1,    -1,    -1,    -1,   185,
     186,   187,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   257,   258,    -1,    -1,    -1,   262,    -1,   264,   265,
      -1,   267,    -1,   269,   270,    -1,    -1,    -1,   274,    -1,
     276,   277,    -1,   279,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   292,    -1,   294,   295,
      -1,   297,    -1,    -1,    -1,   301,   302,    -1,   304,    -1,
     306,   307,    -1,   309,    -1,    -1,    -1,   313,   314,    -1,
     256,    -1,   258,   259,    -1,   261,    -1,    -1,    -1,   265,
     266,    -1,   268,    -1,   270,   271,    -1,   273,    -1,    -1,
      -1,   277,   278,    -1,   280,    -1,   282,   283,    -1,   285,
      -1,    -1,    -1,   289,   290,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   304,   305,
      -1,   307,   308,    -1,   310,   311,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   388,    -1,   390,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   398,    -1,    -1,   401,    -1,    -1,   404,    -1,
      -1,   407,    -1,    -1,    -1,    -1,   412,    -1,   414,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   422,    -1,    -1,   425,
      -1,    -1,   428,    -1,    -1,   431,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    96,    97,    98,    99,    -1,
     386,    -1,    -1,   389,    -1,    -1,   392,    -1,    -1,   395,
      -1,    -1,   458,    -1,    -1,   461,    -1,   403,   464,   405,
      -1,   467,   104,   105,   410,   107,    -1,   413,    -1,   475,
     416,   477,    -1,   419,    -1,    -1,   482,    -1,    -1,   485,
      -1,   427,   488,   429,    -1,   491,    -1,    -1,   434,    -1,
      -1,   437,    -1,   499,   440,   501,    -1,   443,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   451,    -1,   453,   169,   170,
     171,    -1,   173,   174,   175,    -1,   177,   178,   179,    -1,
     181,   182,   183,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   481,    -1,   483,    -1,    -1,
      -1,   487,    -1,   489,    -1,    -1,    -1,   493,    -1,   495,
      -1,    -1,   194,    -1,   196,   197,    -1,   199,    -1,    -1,
      -1,   203,   204,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   256,   257,    -1,   259,   260,
      -1,   262,   263,    -1,    -1,    -1,    -1,   268,   269,    -1,
     271,   272,    -1,   274,   275,    -1,    -1,    -1,    -1,   280,
     281,    -1,   283,   284,    -1,   286,   287,    -1,    -1,    -1,
      -1,   292,   293,    -1,   295,   296,    -1,   298,   299,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   319,    -1,    -1,
     322,    -1,    -1,   325,    -1,    -1,   328,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   336,    -1,   338,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   385,    -1,   387,    -1,    -1,    -1,
     391,    -1,   393,    -1,    -1,    -1,   397,    -1,   399,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   409,    -1,
     411,    -1,    -1,    -1,   415,    -1,   417,    -1,    -1,    -1,
     421,    -1,   423,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   433,    -1,   435,    -1,    -1,    -1,   439,    -1,
     441,    -1,    -1,    -1,   445,    -1,   447,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   457,    -1,   459,    -1,
      -1,    -1,   463,    -1,   465,    -1,    -1,    -1,   469,    -1,
     471,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    16,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    17,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    18,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    19,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    20,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    21,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    22,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    23,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    24,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    25,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    49,    50,    51,    52,    53,    54,    -1,    -1,
      57,    58,    59,    60,    61,    62,    -1,    -1,    65,    66,
      67,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    49,    50,    51,
      52,    53,    54,    -1,    -1,    57,    58,    59,    60,    61,
      62,    -1,    -1,    65,    66,    67
  };

  const unsigned char
  parser::yystos_[] =
  {
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    27,    28,    29,    30,    31,    32,    33,
      34,    49,    50,    51,    52,    53,    54,    57,    58,    59,
      60,    61,    62,    65,    66,    67,    69,    70,    71,    72,
      73,    74,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    96,    97,    98,    99,   100,   101,   120,    35,
      36,   106,   107,   108,   106,   106,   106,   106,   106,   106,
     106,   106,   106,   106,    43,    44,   102,   108,   109,   110,
      42,   116,    37,    38,    39,   103,   107,   108,   111,   112,
     113,    40,    41,   104,   107,   108,   114,   115,    45,   117,
     117,    46,   118,    48,   105,   108,   110,   118,   119,   118,
      71,     0,    65,    66,    71,    72,    73,    74,   120,    74,
      81,    62,    71,    62,    71,    65,   108,   107,    65,    65,
      65,    65,    65,    65,    65,    65,    65,    65,    62,    74,
      62,    74,    65,   109,   110,   108,   110,   108,   109,    62,
      71,    63,    62,    70,    62,    70,    62,    70,    63,   108,
     111,   112,   113,   107,   111,   112,   113,   107,   108,   112,
     113,   107,   108,   111,   113,   107,   108,   111,   112,    62,
      70,    62,    70,    63,   108,   114,   115,   107,   114,   115,
     107,   108,   115,   107,   108,   114,    62,    71,    63,    63,
      62,    71,    63,    62,    74,    63,   110,   118,   119,   108,
     118,   119,   108,   110,   119,   108,   110,   118,    63,    62,
      62,    62,    63,    63,    63,    63,    63,    63,    63,    63,
      63,    63,    63,    62,    62,    63,   110,   109,   110,   108,
     109,   108,    62,    62,    62,    62,   111,   112,   113,   108,
     112,   113,   108,   111,   113,   108,   111,   112,   111,   112,
     113,   107,   112,   113,   107,   111,   113,   107,   111,   112,
     108,   112,   113,   107,   112,   113,   107,   108,   113,   107,
     108,   112,   108,   111,   113,   107,   111,   113,   107,   108,
     113,   107,   108,   111,   108,   111,   112,   107,   111,   112,
     107,   108,   112,   107,   108,   111,    62,    62,   114,   115,
     108,   115,   108,   114,   114,   115,   107,   115,   107,   114,
     108,   115,   107,   115,   107,   108,   108,   114,   107,   114,
     107,   108,    62,    62,    62,   118,   119,   110,   119,   110,
     118,   118,   119,   108,   119,   108,   118,   110,   119,   108,
     119,   108,   110,   110,   118,   108,   118,   108,   110,    70,
      70,    70,    70,    70,    70,    70,    70,    70,    70,    70,
      64,    65,    66,    74,    75,   112,   113,   111,   113,   111,
     112,   112,   113,   108,   113,   108,   112,   111,   113,   108,
     113,   108,   111,   111,   112,   108,   112,   108,   111,   112,
     113,   111,   113,   111,   112,   112,   113,   107,   113,   107,
     112,   111,   113,   107,   113,   107,   111,   111,   112,   107,
     112,   107,   111,   112,   113,   108,   113,   108,   112,   112,
     113,   107,   113,   107,   112,   108,   113,   107,   113,   107,
     108,   108,   112,   107,   112,   107,   108,   111,   113,   108,
     113,   108,   111,   111,   113,   107,   113,   107,   111,   108,
     113,   107,   113,   107,   108,   108,   111,   107,   111,   107,
     108,   111,   112,   108,   112,   108,   111,   111,   112,   107,
     112,   107,   111,   108,   112,   107,   112,   107,   108,   108,
     111,   107,   111,   107,   108,   115,   114,   115,   108,   114,
     108,   115,   114,   115,   107,   114,   107,   115,   108,   115,
     107,   108,   107,   114,   108,   114,   107,   108,   107,   119,
     118,   119,   110,   118,   110,   119,   118,   119,   108,   118,
     108,   119,   110,   119,   108,   110,   108,   118,   110,   118,
     108,   110,   108,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    75,    26,    75,   113,   112,   113,
     111,   112,   111,   113,   112,   113,   108,   112,   108,   113,
     111,   113,   108,   111,   108,   112,   111,   112,   108,   111,
     108,   113,   112,   113,   111,   112,   111,   113,   112,   113,
     107,   112,   107,   113,   111,   113,   107,   111,   107,   112,
     111,   112,   107,   111,   107,   113,   112,   113,   108,   112,
     108,   113,   112,   113,   107,   112,   107,   113,   108,   113,
     107,   108,   107,   112,   108,   112,   107,   108,   107,   113,
     111,   113,   108,   111,   108,   113,   111,   113,   107,   111,
     107,   113,   108,   113,   107,   108,   107,   111,   108,   111,
     107,   108,   107,   112,   111,   112,   108,   111,   108,   112,
     111,   112,   107,   111,   107,   112,   108,   112,   107,   108,
     107,   111,   108,   111,   107,   108,   107,    63
  };

  const unsigned char
  parser::yyr1_[] =
  {
       0,    68,    69,    70,    70,    70,    70,    70,    70,    70,
      70,    70,    70,    70,    70,    70,    71,    71,    71,    71,
      71,    72,    72,    72,    72,    72,    73,    73,    73,    73,
      73,    73,    73,    73,    73,    73,    73,    73,    73,    73,
      73,    73,    73,    73,    73,    73,    74,    75,    75,    75,
      75,    75,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     102,   102,   102,   102,   102,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   104,   104,   104,   104,   104,
     104,   104,   104,   104,   104,   104,   104,   104,   104,   104,
     104,   104,   104,   104,   104,   104,   104,   104,   104,   105,
     105,   105,   105,   105,   105,   105,   105,   105,   105,   105,
     105,   105,   105,   105,   105,   105,   105,   105,   105,   105,
     105,   105,   105,   106,   106,   107,   107,   107,   108,   108,
     108,   109,   109,   109,   110,   110,   110,   111,   111,   111,
     112,   112,   112,   113,   113,   113,   114,   114,   114,   115,
     115,   115,   116,   116,   116,   117,   117,   117,   118,   118,
     118,   119,   119,   119,   120,   120,   120,   120,   120
  };

  const unsigned char
  parser::yyr2_[] =
  {
       0,     2,     1,     1,     2,     1,     2,     2,     1,     2,
       1,     2,     1,     2,     1,     2,     1,     2,     1,     2,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       3,     2,     0,     1,     1,     1,     1,     1,     6,     6,
       6,     6,     6,     6,     6,     6,     6,     6,     6,     6,
       1,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     5,     5,     5,     5,     5,
       5,     5,     5,     5,     5,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     2,     2,     3,     2,     0,     3,     2,
       0,     3,     2,     0,     3,     2,     0,     3,     2,     0,
       3,     2,     0,     3,     2,     0,     3,     2,     0,     3,
       2,     0,     3,     2,     0,     3,     2,     0,     3,     2,
       0,     3,     2,     0,     1,     1,     1,     1,     1
  };


#if YYDEBUG
  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a yyntokens_, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "\"end of file\"", "error", "$undefined", "OPENAGHLEMMASTART",
  "OPENAGHDEFINITIONSTART", "OPENAGHEXAMPLESTART", "OPENAGHLAWSTART",
  "OPENAGHRULESTART", "OPENAGHCONCLUSIONSTART", "OPENAGHDERIVATIONSTART",
  "OPENAGHSUMMARYSTART", "OPENAGHINFORMATIONSTART",
  "OPENAGHANNOTATIONSTART", "OPENAGHPROPERTYSTART", "OPENAGHMATHJAXSTART",
  "OPENAGHLEMMAEND", "OPENAGHDEFINITIONEND", "OPENAGHEXAMPLEEND",
  "OPENAGHLAWEND", "OPENAGHRULEEND", "OPENAGHCONCLUSIONEND",
  "OPENAGHDERIVATIONEND", "OPENAGHSUMMARYEND", "OPENAGHINFORMATIONEND",
  "OPENAGHANNOTATIONEND", "OPENAGHPROPERTYEND", "OPENAGHMATHJAXEND",
  "OPENAGHNOTESTART", "OPENAGHTHEOREMSTART", "OPENAGHEXERCISESTART",
  "OPENAGHQUOTATIONSSTART", "OPENAGHNOTESSTART", "OPENAGHSIMULATIONSTART",
  "OPENAGHIMGFORMULASTART", "OPENAGHCHEMEVISUALIZATIONSTART", "XNAME",
  "XANCHOR", "XASSUMPTIONS", "XTHESIS", "XPROOF", "XCONTENT", "XSOLUTION",
  "XNOTE", "XTYPE", "XISNUMERATION", "XHEADLINE", "XFILEID", "XCAPTION",
  "XFORMULATYPE", "IMG", "VIMEO", "YOUTUBE", "MEDIAPLAYER", "SUB",
  "OPENAGHQUOTATION", "TABLEHEADSTART", "TABLEHEADEND", "ERRMATH",
  "ERRWRSURR", "ERRDOUBLEBR", "ERRINVSURR", "ERRDOUBLEDOLLAR", "QU", "BR",
  "BL", "NR", "NL", "TEXT", "$accept", "root", "module", "modulesimple",
  "tiki", "openagh", "text", "math", "img", "vimeo", "youtube",
  "mediaplayer", "sub", "openaghmathjax", "openaghlemma",
  "openaghdefinition", "openaghexample", "openaghlaw", "openaghrule",
  "openaghconclusion", "openaghderivation", "openaghsummary",
  "openaghinformation", "openaghannotation", "openaghproperty",
  "openaghquotation", "openaghquotations", "openaghnote", "openaghnotes",
  "openaghsimulation", "openaghtheorem", "openaghexercise",
  "openaghimgformula", "openaghchemevisualization", "xopenaghmathjaxattrs",
  "xopenaghtheoremattrs", "xopenaghexerciseattrs",
  "xopenaghimgformulaattrs", "x_name_anchor", "xname", "xanchor",
  "xisnumeration", "xtype", "xassumptions", "xthesis", "xproof",
  "xcontent", "xsolution", "xnote", "xheadline", "xfileid", "xformulatype",
  "errmath", YY_NULLPTR
  };


  const unsigned short int
  parser::yyrline_[] =
  {
       0,   124,   124,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   144,   145,   146,   147,
     148,   152,   153,   154,   155,   156,   160,   161,   162,   163,
     164,   165,   166,   167,   168,   169,   170,   171,   172,   173,
     174,   175,   176,   177,   178,   179,   183,   187,   188,   189,
     190,   191,   192,   200,   204,   208,   212,   216,   223,   226,
     229,   232,   235,   238,   241,   244,   247,   250,   253,   256,
     263,   267,   271,   275,   279,   283,   287,   291,   295,   306,
     307,   308,   309,   310,   311,   324,   325,   326,   327,   328,
     329,   330,   331,   332,   333,   334,   335,   336,   337,   338,
     339,   340,   341,   342,   343,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,   355,   356,   357,   358,
     359,   360,   361,   362,   363,   364,   365,   366,   367,   368,
     369,   370,   371,   372,   373,   374,   375,   376,   377,   378,
     379,   380,   381,   382,   383,   384,   385,   386,   387,   388,
     389,   390,   391,   392,   393,   394,   395,   396,   397,   398,
     399,   400,   401,   402,   403,   404,   405,   406,   407,   408,
     409,   410,   411,   412,   413,   414,   415,   416,   417,   418,
     419,   420,   421,   422,   423,   424,   425,   426,   427,   428,
     429,   430,   431,   432,   433,   434,   435,   436,   437,   438,
     439,   440,   441,   442,   443,   455,   456,   457,   458,   459,
     460,   461,   462,   463,   464,   465,   466,   467,   468,   469,
     470,   471,   472,   473,   474,   475,   476,   477,   478,   482,
     483,   484,   485,   486,   487,   488,   489,   490,   491,   492,
     493,   494,   495,   496,   497,   498,   499,   500,   501,   502,
     503,   504,   505,   515,   516,   524,   525,   526,   530,   531,
     532,   536,   537,   538,   542,   543,   544,   548,   549,   550,
     554,   555,   556,   560,   561,   562,   566,   567,   568,   572,
     573,   574,   578,   579,   580,   584,   585,   586,   590,   591,
     592,   596,   597,   598,   606,   607,   608,   609,   610
  };

  // Print the state stack on the debug stream.
  void
  parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << i->state;
    *yycdebug_ << std::endl;
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  parser::yy_reduce_print_ (int yyrule)
  {
    unsigned int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):" << std::endl;
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG



} // yy
#line 3732 "gen/parser.tab.cc" // lalr1.cc:1167
#line 613 "src/parser.yy" // lalr1.cc:1168


